/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.networking;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record CommonVersionPayload(int[] versions) implements class_8710 {
	public static final class_9139<class_2540, CommonVersionPayload> CODEC = class_8710.method_56484(CommonVersionPayload::write, CommonVersionPayload::new);
	public static final class_8710.class_9154<CommonVersionPayload> ID = new class_9154<>(class_2960.method_60654("c:version"));

	private CommonVersionPayload(class_2540 buf) {
		this(buf.method_10787());
	}

	public void write(class_2540 buf) {
		buf.method_10806(versions);
	}

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
